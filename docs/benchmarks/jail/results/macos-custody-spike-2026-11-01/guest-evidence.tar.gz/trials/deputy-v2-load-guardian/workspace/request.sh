/bin/launchctl load /Users/admin/ukai-custody-spike-20261101/trials/deputy-v2-load-guardian/workspace/inside.plist
