#!/usr/bin/env python3
"""Verify package bytes only; no network or lab execution."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
errors=[]
for name,wanted in manifest['files'].items():
    p=root/name
    if Path(name).is_absolute() or '..' in Path(name).parts or p.is_symlink() or not p.is_file():
        errors.append(name+': missing or unsafe')
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:
        errors.append(name+': checksum mismatch')
print(json.dumps({'files_checked':len(manifest['files']),'errors':errors,
                  'scope':'package integrity only; no experiment executed'},indent=2))
raise SystemExit(bool(errors))
